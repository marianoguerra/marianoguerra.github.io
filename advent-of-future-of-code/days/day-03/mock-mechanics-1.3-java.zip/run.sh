#!/bin/bash

java -jar --illegal-access=deny program.jar 
