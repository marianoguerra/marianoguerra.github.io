
;; show button shortcut reminders
:show-hints true

;; :always - show menu buttons in all modes
;; :no-sim - all modes except simulation
;; :never  - you get the idea
:show-buttons :always
